package job;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("login")
public class LoginController {
	
	HiberOperations db=new HiberOperations();
	
	@Autowired
	ServiceProvider userBean;

	public ServiceProvider getUserBean() {
		return userBean;
	}


	public void setUserBean(ServiceProvider userBean) {
		this.userBean = userBean;
	}
	
	@Autowired
	ServiceRequester requestbean;

	public ServiceRequester getRequestbean() {
		return requestbean;
	}


	public void setRequestbean(ServiceRequester requestbean) {
		this.requestbean = requestbean;
	}


	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView getmethod()
	{
		ServiceProvider userbean=new ServiceProvider();
		ServiceRequester requestbean=new ServiceRequester();
		ModelAndView mdlvie=new ModelAndView();
		mdlvie.setViewName("login");
		mdlvie.addObject("userbean",userbean);
		
		mdlvie.addObject("requestbean",requestbean);
		
		return mdlvie;
	}
	
	
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView userbeandemo(ServiceProvider bean,HttpSession session,Jobs jobbean)
	{
		
		ModelAndView mdlvie=new ModelAndView();

		if(db.checkuser(bean.getSp_username().toString().trim()))
		{
			System.out.println("Am Here");
				if(db.checkUserAndPassword(bean.getSp_username().toString().trim(),bean.getSp_password().toString().trim()))
				{
					System.out.println("UserName:"+bean.getSp_username());
					System.out.println("Password:"+bean.getSp_password());
					db.changestatus(bean.getSp_username().toString().trim(),1);
					mdlvie.addObject("jobbean",jobbean);
					mdlvie.setViewName("index");
					session.setAttribute("username",bean.getSp_username());
				}
				else
				{
					mdlvie.setViewName("login");
				}
		}
		else
		{
			mdlvie.setViewName("Register");
		}
		
		
		
		mdlvie.addObject("userbean",bean);
		return mdlvie;
		
	}
	

}
