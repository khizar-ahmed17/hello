package job;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("shopping")
public class ShoppingController {

	@Autowired
	UserBean userbean;
	
	public UserBean getUserbean() {
		return userbean;
	}

	public void setUserbean(UserBean userbean) {
		this.userbean = userbean;
	}
	
	@Autowired
	ProductBean pbean;

	public ProductBean getPbean() {
		return pbean;
	}

	public void setPbean(ProductBean pbean) {
		this.pbean = pbean;
	}

	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView moveShoppingPage()
	{
		
		ModelAndView mandv=new ModelAndView();
		ProductBean pbean=new ProductBean();
		mandv.setViewName("Shop1");
		mandv.addObject("pbean",pbean);
		
		return mandv;
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView shoppingproduct(ProductBean pbean,HttpSession session)
	{
		ModelAndView mandv=new ModelAndView();
		
	
		
		if(pbean.getP1()!=null)session.setAttribute(pbean.getP1(),pbean.getP1());
		if(pbean.getP2()!=null)session.setAttribute(pbean.getP2(),pbean.getP2());
		if(pbean.getP3()!=null)session.setAttribute(pbean.getP3(),pbean.getP3());
		
		
		mandv.addObject("pbean",pbean);
		mandv.setViewName(pbean.getPage());
		
		
		return mandv;
		
	}
	
	
}
