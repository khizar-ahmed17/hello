package job;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;



public class HiberOperations 
{
	Session session;
	
	
	public boolean checkuser(String uname)
	{
		session=SessionUtility.GetSessionConnection();
				
		String hql = "FROM job.ServiceProvider where sp_username = :username";
		System.out.println(uname);
		Query query = session.createQuery(hql);
		query.setString("username",uname);
		

		
		
		@SuppressWarnings("unchecked")
		List<ServiceProvider> results = query.list();
		System.out.println(results);
		Iterator<ServiceProvider> it=results.iterator();
		
		if (it.hasNext()) {
			
			return true;
		}
		else
		{
			
		return false;
		}
	
	}
	
	
	public boolean changestatus(String uname,int status)
	{
		 session=SessionUtility.GetSessionConnection();
		
		Query query = session.createQuery("update job.ServiceProvider set sp_status = :statusval where sp_username = :unameval");
		
		query.setParameter("statusval",status);
		query.setParameter("unameval",uname);
		
		if (query.executeUpdate()==1) {
			
			SessionUtility.closeSession(null);
			return true;
		}
		else
		{
			return false;
		}
		
		
		
	}
	
	
	public boolean changepassword(String uname,String password)
	{
		 session=SessionUtility.GetSessionConnection();
		
		Query query = session.createQuery("update UserEntity set upass = :statusval where uname = :unameval");
		
		query.setParameter("statusval",password);
		query.setParameter("unameval",uname);
		
		if (query.executeUpdate()==1) {
			
			SessionUtility.closeSession(null);
			return true;
		}
		else
		{
			return false;
		}
		
		
		
	}
	
	
	
	public boolean checkUserAndPassword(String uname,String password){
		
		
		 session=SessionUtility.GetSessionConnection();	
		String hql = "FROM job.ServiceProvider where sp_username = :username AND sp_password= :password";
		Query query = session.createQuery(hql);
		query.setParameter("username",uname);
		query.setParameter("password",password);
		
		
		@SuppressWarnings("unchecked")
		List<ServiceProvider> results = query.list();
		
		Iterator<ServiceProvider> it=results.iterator();	
		
		if (it.hasNext()) {
			
			return true;
		}
		else
		{
			
		return false;
		}	
	}
	
	
	public boolean checkstatus(String uname)
	{
		
		 session=SessionUtility.GetSessionConnection();
		
		String hql = "FROM ServiceProvider where sp_username = :username";
		
		Query query = session.createQuery(hql);
		
		query.setParameter("username",uname);
		
		@SuppressWarnings("unchecked")
		List<ServiceProvider> results = query.list();	
		Iterator<ServiceProvider> it=results.iterator();
		
		System.out.println(it);
		ServiceProvider sp=it.next();
		
		if (sp.getSp_status()==1) {
			
			return true;
		}
		else
		{
			
		return false;
		}
		
	}
	
	
	
	public boolean InsertDatabase(String uname,String password,String email,String website,String address)
	{
		 session=SessionUtility.GetSessionConnection(); 
			ServiceProvider service=new ServiceProvider();
			service.setSp_username(uname);
			service.setSp_password(password);
			service.setSp_email(email);
			service.setSp_website(website);
			service.setSp_address(address);
			service.setSp_status(0);
			service.setSp_id(1);
			
			
		
			
			
			
//			Jobs j=new Jobs();
//			j.setJob_id(1);
//			j.setJob_name("java developer");
//			j.setJob_amount(5000);
//			j.setJob_experience("2 Years");
//			j.setSpobj(service);
			//Set<Jobs> set=new HashSet<Jobs>();
			//set.add(j);
			//set.add(j1);
			//service.setJobs(set);
			
			
			//session.save(j);
			//session.save(j1);
		 
		 try{
			 session.save(service);
				//session.save(j);
				//session.save(j1); 
		 SessionUtility.closeSession(null);
		 return true;
		 }
		 catch(Exception e1)
		 {
			 System.out.println("failed insert"+e1);
			 return false;
		 }
		 
		
	
	}
	
	public boolean Addjob(int id,String j_name,String j_spec,String j_exp,int j_amt)
	{
		 session=SessionUtility.GetSessionConnection(); 
		Jobs j=new Jobs();
		j.setJob_id(id);
		j.setJob_name(j_name);
		j.setJob_specialization(j_spec);
		j.setJob_experience(j_exp);
		j.setJob_amount(j_amt);
		//j.setSpobj(service);
		session.save(j);
		//session.getSession(service);
		Set<Jobs> set=new HashSet<Jobs>();
		set.add(j);
	
		//service.setJobs(set);
			
		
			
			
			
//			Jobs j=new Jobs();
//			j.setJob_id(1);
//			j.setJob_name("java developer");
//			j.setJob_amount(5000);
//			j.setJob_experience("2 Years");
//			j.setSpobj(service);
			//Set<Jobs> set=new HashSet<Jobs>();
			//set.add(j);
			//set.add(j1);
			//service.setJobs(set);
			
			
			//session.save(j);
			//session.save(j1);
		 
		 try{
			 	session.save(j);
				//session.getSession(service);
				//Set<Jobs> set=new HashSet<Jobs>();
				//set.add(j);
			 	SessionUtility.closeSession(null);
		 return true;
		 }
		 catch(Exception e1)
		 {
			 System.out.println("failed insert"+e1);
			 return false;
		 }
		 
		
	
	}


	
	
	public static void main(String[] args) 
	{
	HiberOperations hb=new HiberOperations();
	System.out.println(hb.Addjob(1,"Web Designer","html5","2 yrs",20000));
	}
	
	
	

}
