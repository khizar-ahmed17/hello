package job;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("requestapply")
public class ApplyController
{
	@Autowired
	ServiceProvider providerbean;
	
	public ServiceProvider getProviderbean() {
		return providerbean;
	}

	public void setProviderbean(ServiceProvider providerbean) {
		this.providerbean = providerbean;
	}

	@Autowired
	Jobs jobbean;
	
	public Jobs getJobbean() {
		return jobbean;
	}

	public void setJobbean(Jobs jobbean) {
		this.jobbean = jobbean;
	}

	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView movetoposition(Applied a,Jobs jobbean,ServiceRequester requestbean,HttpSession session)
	{
	String i=(String) session.getAttribute("username");
		
		System.out.println(i);
		if(i==null)
		{
			ServiceProvider userbean=new ServiceProvider();
			ModelAndView mdlvie=new ModelAndView();
			mdlvie.setViewName("login");
			mdlvie.addObject("userbean",userbean);
			
			mdlvie.addObject("requestbean",requestbean);
			
			return mdlvie;
		}
		else
		{
		
		
		
			System.out.println("In Get method of ApplyControl");
			int getspid=0;
			int reqid = 0;
			String reqname=null;
			
			String uname=session.getAttribute("username").toString().trim();
			
			System.out.println("Session username:"+uname);
			Session session1=(Session)SessionUtility.GetSessionConnection();
			  Criteria criteria = session1.createCriteria(ServiceRequester.class);
			   
              criteria.add(Restrictions.eq("rq_username",uname));
              ServiceRequester requester = (ServiceRequester) criteria.uniqueResult();
              
              if (requester!=null) 
              {
            	  System.out.println("Requestid Found");
            	  reqid=requester.getRq_id();
            	  reqname=requester.getRq_name();
                  System.out.println(requester.getRq_id() + " - " + requester.getRq_name());
  
              }
			
			String reqjobname=null;
			String cname=null;
			
			System.out.println("name:"+requestbean.getRq_name());
			ModelAndView mdlv=new ModelAndView();
			System.out.println("Reqid:"+reqid);
			System.out.println("Job name:"+jobbean.getCheckjobs());
			System.out.println(jobbean.getProduct());
			for (String s  : jobbean.getProduct()) {
				//session.setAttribute(s.toString().trim(),s.toString().trim());
				System.out.println("checked job name:"+s);
				reqjobname=s;
				
				}
			
		
			String hql = "FROM job.Jobs where job_name = :jobname";
			
			Query query = session1.createQuery(hql);
			query.setString("jobname",reqjobname);
			
			

			
			
			@SuppressWarnings("unchecked")
			List<Jobs> results = query.list();
			System.out.println(results);
			Iterator<Jobs> it=results.iterator();
			
			if (it.hasNext())
			{
				getspid=it.next().getSpobj().getSp_id();
				cname=it.next().getSpobj().getSp_username();
				
//				cname=it.next().getSpobj().getSp_username();
//				System.out.println("ServiceProviderID:"+getspid);
//				System.out.println("CompanyName:"+it.next().getSpobj().getSp_username());
				
				//updating the applyrequest to reqid value
			}
			
			
			Session session2=(Session)SessionUtility.GetSessionConnection();
			String hql1 = "FROM job.Applied where appobj = :appobjid";
			//Query query1 = session1.createQuery(hql1);
			Query query1 = session1.createQuery(hql1);
			query1.setInteger("appobjid", getspid);
			@SuppressWarnings("unchecked")
			List<Applied> results1 = query1.list();
			System.out.println(results1);
			Iterator<Applied> iter=results1.iterator();
			
			ServiceProvider obj = null;
			
//			List<ServiceProvider> apply = null;
//			apply.add(getProviderbean());
			
			if(iter.hasNext())
			{
				obj=iter.next().getAppobj();
				System.out.println("ServiceProvider obj:"+obj);
				System.out.println("Am here at last");
				System.out.println("updated");
				//session1.save(hql);
				
			}
		
			
			Applied appl=new Applied();
			appl.setApplied(reqid);
			appl.setRequestername(reqname);
			appl.setJobname(reqjobname);
			appl.setAppobj(obj);
			session1.save(appl);
			SessionUtility.closeSession(null);
			
			
			
			
			
			/*sample try with lisiting add and save
			
				String hql1 = "FROM job.ServiceProvider where sp_id = :spid";
				//Query query1 = session1.createQuery(hql1);
				Query query1 = session1.createQuery(hql1);
				query1.setInteger("spid", getspid);
				@SuppressWarnings("unchecked")
				List<ServiceProvider> results1 = query1.list();
				System.out.println(results1);
				Iterator<ServiceProvider> iter=results1.iterator();
				
				//Extras
				ServiceProvider u=(ServiceProvider) query1.list().get(0);
				a.setApplied(5);
				Set<Applied> set1=u.getApplied();
				set1.add(a);
				u.setApplied(set1);
				session1.save(a);
				session1.save(u);
				
				
				
//				List<ServiceProvider> apply;
//				apply.add(getProviderbean());
				
				if(iter.hasNext())
				{
					System.out.println("Am here at last");
					iter.next().setApply_request(reqid);
					System.out.println("updated");
					//session1.save(hql);
					SessionUtility.closeSession(null);
				}
						
//			ServiceProvider providerbean=new ServiceProvider();
//			Session session=(Session)SessionUtility.GetSessionConnection();
//			String hql = "FROM job.ServiceProvider";
//			Query query = session.createQuery(hql);
//			List<ServiceProvider> results = query.list();
//			Iterator<ServiceProvider> it=results.iterator();
//			it.next().setApply_request(1);
 * 
 * 
 * 
 * */
 
			mdlv.setViewName("inindex");
			mdlv.addObject("jobbean",jobbean);
			mdlv.addObject("providerbean",providerbean);
			
			//SessionUtility.closeSession(null);
			return mdlv;
		
		}
	}
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView nextposition(Jobs jobbean)
	{
		System.out.println("In post method of Appply control");
		System.out.println("Am here");
		ModelAndView md=new ModelAndView();
		
		
	//	md.addObject("positions",results);
		md.addObject("jobbean",jobbean);
		md.setViewName("index");
		return md;
		
	}
	
	
}
