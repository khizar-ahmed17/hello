package job;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.classic.Session;

public class Include 
{
	
	public static void main(String[] args) 
	{
		ServiceProvider service=new ServiceProvider();
		service.setSp_username("company");
		service.setSp_password("root");
		service.setSp_email("company@gamil.com");
		service.setSp_website("company.com");
		service.setSp_status(0);
		service.setSp_address("1st Street");
		service.setApply_request(0);
		

		Jobs j=new Jobs();
		j.setJob_id(1);
		j.setJob_name("java developer");
		j.setJob_amount(5000);
		j.setJob_experience("2 Years");
		j.setJob_specialization("python");
		j.setSpobj(service);
		
		Set<Jobs> set=new HashSet<Jobs>();
		
		set.add(j);
		service.setJobs(set);
		
		Session session=(Session) SessionUtility.GetSessionConnection();
		session.save(service);
		session.save(j);
		
		
	
		
		
	}

}
