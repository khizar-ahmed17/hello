package job;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("requestdetails")
public class CompanyDetails
{
	@Autowired
	ServiceProvider userbean;
	
	public ServiceProvider getUserbean() {
		return userbean;
	}

	public void setUserbean(ServiceProvider userbean) {
		this.userbean = userbean;
	}
	
	
	@Autowired
	ServiceRequester requestbean;

	public ServiceRequester getRequestbean() {
		return requestbean;
	}

	public void setRequestbean(ServiceRequester requestbean) {
		this.requestbean = requestbean;
	}


	@Autowired
	ServiceProvider providerbean;
	
	public ServiceProvider getProviderbean() {
		return providerbean;
	}

	public void setProviderbean(ServiceProvider providerbean) {
		this.providerbean = providerbean;
	}


	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView movetoposition(ServiceProvider providerbean,HttpSession session)
	{
		String i=(String) session.getAttribute("username");
		
		System.out.println(i);
		if(i==null)
		{
			ServiceProvider userbean=new ServiceProvider();
			ServiceRequester requestbean=new ServiceRequester();
			ModelAndView mdlvie=new ModelAndView();
			mdlvie.setViewName("login");
			mdlvie.addObject("userbean",userbean);
			
			mdlvie.addObject("requestbean",requestbean);
			
			return mdlvie;
		}
		else
		{
		
			System.out.println("In Get method of Company Details");
			String companyname=null;
		
			Session session1=(Session)SessionUtility.GetSessionConnection();
			ModelAndView mdlv=new ModelAndView();
			
			System.out.println(providerbean.getProduct());
			for (String s  : providerbean.getProduct()) {
				//session.setAttribute(s.toString().trim(),s.toString().trim());
				System.out.println("checked job name:"+s);
				companyname=s;
				
				}
			System.out.println("Selected Company:"+companyname);
		
		//	String hql = "FROM job.Jobs where job_name = :jobname";
			String hql = "FROM job.ServiceProvider where sp_username = :name";
			Query query = session1.createQuery(hql);
			query.setString("name",companyname);
			
			

			
			
			@SuppressWarnings("unchecked")
			List<ServiceProvider> results = query.list();
			System.out.println(results);
			Iterator<ServiceProvider> it=results.iterator();
			
			if (it.hasNext())
			{
				System.out.println("Address:"+it.next().getSp_address());
				
				//updating the applyrequest to reqid value
			}
			
			
			mdlv.addObject("companydetails",results);
				
				
//				
//			ServiceProvider providerbean=new ServiceProvider();
//			Session session=(Session)SessionUtility.GetSessionConnection();
//			String hql = "FROM job.ServiceProvider";
//			Query query = session.createQuery(hql);
//			List<ServiceProvider> results = query.list();
//			Iterator<ServiceProvider> it=results.iterator();
//			it.next().setApply_request(1);
			mdlv.setViewName("requestdetails");
			
			mdlv.addObject("providerbean",providerbean);
			
			//SessionUtility.closeSession(null);
			return mdlv;
			}
		}
	
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView nextposition(ServiceProvider providerbean)
	{
		System.out.println("In post method of Appply control");
		System.out.println("Am here");
		ModelAndView md=new ModelAndView();
		
		
	//	md.addObject("positions",results);
		md.addObject("providerbean",providerbean);
		md.setViewName("requestdetails");
		return md;
		
	}
	
	
}
